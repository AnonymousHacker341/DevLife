﻿# PowerShell RPG Economy System - "DevLife Simulator"
# The most advanced PowerShell gaming system ever created!

# Initialize persistent data storage
$global:SavePath = "$env:APPDATA\DevLifeSimulator"
$global:SaveFile = "$global:SavePath\player.json"

# Create save directory if it doesn't exist
if (!(Test-Path $global:SavePath)) {
    New-Item -ItemType Directory -Path $global:SavePath -Force | Out-Null
}

# Player data structure
function Initialize-Player {
    return @{
        Name = $env:USERNAME
        Level = 1
        XP = 0
        Coins = 100
        Energy = 100
        MaxEnergy = 100
        Items = @{}
        Achievements = @()
        PlayTime = 0
        LastLogin = (Get-Date).ToString()
        Stats = @{
            BugsFixed = 0
            CoffeeConsumed = 0
            LinesOfCode = 0
            DeploymentsFailed = 0
            StackOverflowVisits = 0
        }
    }
}

# Save/Load functions
function Save-Player($player) {
    $player | ConvertTo-Json -Depth 10 | Out-File -FilePath $global:SaveFile -Encoding UTF8
}

function Load-Player {
    if (Test-Path $global:SaveFile) {
        $player = Get-Content -Path $global:SaveFile -Raw | ConvertFrom-Json
        # Convert back to proper hashtables
        $playerHash = @{}
        $player.PSObject.Properties | ForEach-Object { $playerHash[$_.Name] = $_.Value }
        return $playerHash
    }
    return Initialize-Player
}

# XP and leveling system
function Add-XP($player, $amount) {
    $player.XP += $amount
    $newLevel = [Math]::Floor($player.XP / 1000) + 1
    
    if ($newLevel -gt $player.Level) {
        $player.Level = $newLevel
        $player.MaxEnergy += 20
        $player.Energy = $player.MaxEnergy
        Write-Host "🎉 LEVEL UP! You are now level $newLevel!" -ForegroundColor Magenta
        Write-Host "💪 Max energy increased to $($player.MaxEnergy)!" -ForegroundColor Green
        Add-Coins $player (50 * $newLevel)
        return $true
    }
    return $false
}

function Add-Coins($player, $amount) {
    $player.Coins += $amount
    Write-Host "💰 +$amount coins! Total: $($player.Coins)" -ForegroundColor Yellow
}

# Shop system
function Show-Shop($player) {
    Clear-Host
    Write-Host @"
    ╔═══════════════════════════════════════════════════════════╗
    ║                    🛒 DEV SHOP 🛒                        ║
    ║              Your coins: $($player.Coins.ToString().PadLeft(6)) 💰                    ║
    ╚═══════════════════════════════════════════════════════════╝
"@ -ForegroundColor Cyan

    $shopItems = @{
        1 = @{ Name = "Energy Drink"; Price = 50; Effect = "Restore 50 energy"; Type = "consumable" }
        2 = @{ Name = "Rubber Duck"; Price = 200; Effect = "Debug luck +25%"; Type = "permanent" }
        3 = @{ Name = "Mechanical Keyboard"; Price = 500; Effect = "Coding speed +50%"; Type = "permanent" }
        4 = @{ Name = "Second Monitor"; Price = 1000; Effect = "Productivity +100%"; Type = "permanent" }
        5 = @{ Name = "Gaming Chair"; Price = 1500; Effect = "Comfort +200%"; Type = "permanent" }
        6 = @{ Name = "Lottery Ticket"; Price = 100; Effect = "Random surprise!"; Type = "gamble" }
    }

    foreach ($item in $shopItems.GetEnumerator() | Sort-Object Key) {
        $owned = if ($player.Items.ContainsKey($item.Value.Name)) { " ✅ OWNED" } else { "" }
        Write-Host "$($item.Key). $($item.Value.Name) - $($item.Value.Price)💰 ($($item.Value.Effect))$owned" -ForegroundColor Gray
    }

    Write-Host "`nEnter item number to buy (0 to exit): " -NoNewline -ForegroundColor Cyan
    $choice = Read-Host

    if ($choice -ge 1 -and $choice -le 6 -and $shopItems.ContainsKey([int]$choice)) {
        $item = $shopItems[[int]$choice]
        
        if ($player.Coins -ge $item.Price) {
            $player.Coins -= $item.Price
            
            switch ($item.Type) {
                "consumable" {
                    if ($item.Name -eq "Energy Drink") {
                        $player.Energy = [Math]::Min($player.Energy + 50, $player.MaxEnergy)
                        Write-Host "⚡ Energy restored! Current energy: $($player.Energy)" -ForegroundColor Green
                    }
                }
                "permanent" {
                    $player.Items[$item.Name] = $true
                    Write-Host "🎁 $($item.Name) acquired! $($item.Effect)" -ForegroundColor Green
                }
                "gamble" {
                    $surprise = Get-Random -Minimum 1 -Maximum 6
                    switch ($surprise) {
                        1 { 
                            $winnings = Get-Random -Minimum 200 -Maximum 1000
                            Add-Coins $player $winnings
                            Write-Host "🎰 JACKPOT! You won $winnings coins!" -ForegroundColor Magenta
                        }
                        2 { 
                            Add-XP $player 500
                            Write-Host "📚 You found a rare programming book! +500 XP!" -ForegroundColor Blue
                        }
                        3 { 
                            Write-Host "💥 The ticket was a dud! Better luck next time!" -ForegroundColor Red
                        }
                        4 {
                            $player.Energy = $player.MaxEnergy
                            Write-Host "☕ You won a lifetime supply of coffee! Energy fully restored!" -ForegroundColor Brown
                        }
                        5 {
                            Write-Host "🐛 You accidentally introduced a bug in production! Oops!" -ForegroundColor Red
                            $player.Stats.DeploymentsFailed++
                        }
                    }
                }
            }
            Save-Player $player
        } else {
            Write-Host "💸 Not enough coins! You need $($item.Price - $player.Coins) more coins." -ForegroundColor Red
        }
    }
}

# Adventure system with economy integration
function Start-Adventure($player) {
    if ($player.Energy -lt 20) {
        Write-Host "😴 You're too tired for an adventure! Buy an energy drink or wait." -ForegroundColor Red
        return
    }

    $player.Energy -= 20
    
    $adventures = @(
        @{
            name = "Debug Quest"
            description = "A wild NullPointerException appears!"
            rewards = @{ xp = 150; coins = 75; stat = "BugsFixed" }
            success = "🐛 Bug squashed! Your debugging skills improve!"
            failure = "💥 The bug reproduced in production! Stack Overflow time!"
        },
        @{
            name = "Code Review"
            description = "Senior dev requests code review"
            rewards = @{ xp = 200; coins = 100; stat = "LinesOfCode" }
            success = "✅ Clean code approved! Your reputation grows!"
            failure = "😅 'Needs refactoring' - back to the drawing board!"
        },
        @{
            name = "Coffee Run"
            description = "The coffee machine is calling your name"
            rewards = @{ xp = 50; coins = 25; stat = "CoffeeConsumed" }
            success = "☕ Perfect brew achieved! Productivity +1000%!"
            failure = "🤢 Decaf by mistake! Your soul dies a little."
        },
        @{
            name = "Stack Overflow Dive"
            description = "Time to copy-paste some solutions"
            rewards = @{ xp = 100; coins = 50; stat = "StackOverflowVisits" }
            success = "💡 Found the perfect answer! Problem solved!"
            failure = "😵 6 hours later, still reading discussions..."
        }
    )

    $adventure = $adventures | Get-Random
    
    Write-Host "`n🗡️ $($adventure.name): $($adventure.description)" -ForegroundColor Yellow
    
    # Calculate success chance based on items
    $successChance = 0.6
    if ($player.Items.ContainsKey("Rubber Duck")) { $successChance += 0.25 }
    if ($player.Items.ContainsKey("Mechanical Keyboard")) { $successChance += 0.15 }
    
    $success = (Get-Random) -lt $successChance
    
    if ($success) {
        Write-Host $adventure.success -ForegroundColor Green
        Add-XP $player $adventure.rewards.xp
        Add-Coins $player $adventure.rewards.coins
        $player.Stats[$adventure.rewards.stat]++
        
        # Random bonus rewards
        if ((Get-Random) -lt 0.1) {
            $bonus = Get-Random -Minimum 50 -Maximum 200
            Add-Coins $player $bonus
            Write-Host "🎁 BONUS REWARD! +$bonus coins!" -ForegroundColor Magenta
        }
    } else {
        Write-Host $adventure.failure -ForegroundColor Red
        Add-XP $player ($adventure.rewards.xp / 2)
        Write-Host "📚 At least you learned something! +$($adventure.rewards.xp / 2) XP" -ForegroundColor Blue
    }
    
    Save-Player $player
}

# Stats and achievements
function Show-Stats($player) {
    Clear-Host
    Write-Host @"
    ╔═══════════════════════════════════════════════════════════╗
    ║                   📊 PLAYER STATS 📊                     ║
    ╚═══════════════════════════════════════════════════════════╝
"@ -ForegroundColor Cyan

    Write-Host "👤 Name: $($player.Name)" -ForegroundColor White
    Write-Host "⭐ Level: $($player.Level)" -ForegroundColor Yellow
    Write-Host "🎯 XP: $($player.XP) / $($player.Level * 1000) ($(($player.XP % 1000) / 10)% to next level)" -ForegroundColor Blue
    Write-Host "💰 Coins: $($player.Coins)" -ForegroundColor Yellow
    Write-Host "⚡ Energy: $($player.Energy) / $($player.MaxEnergy)" -ForegroundColor Green
    Write-Host ""
    Write-Host "🏆 ACHIEVEMENTS:" -ForegroundColor Magenta
    Write-Host "🐛 Bugs Fixed: $($player.Stats.BugsFixed)" -ForegroundColor Gray
    Write-Host "☕ Coffee Consumed: $($player.Stats.CoffeeConsumed)" -ForegroundColor Brown
    Write-Host "💻 Lines of Code: $($player.Stats.LinesOfCode)" -ForegroundColor Cyan
    Write-Host "💥 Failed Deployments: $($player.Stats.DeploymentsFailed)" -ForegroundColor Red
    Write-Host "🔍 Stack Overflow Visits: $($player.Stats.StackOverflowVisits)" -ForegroundColor Orange
    
    Write-Host "`n🎒 INVENTORY:" -ForegroundColor Green
    if ($player.Items.Count -gt 0) {
        $player.Items.Keys | ForEach-Object { Write-Host "  • $_" -ForegroundColor Gray }
    } else {
        Write-Host "  Empty - visit the shop!" -ForegroundColor Gray
    }
}

# Daily bonus system
function Claim-DailyBonus($player) {
    $today = (Get-Date).Date
    $lastLogin = [DateTime]::Parse($player.LastLogin).Date
    
    if ($today -gt $lastLogin) {
        $bonus = Get-Random -Minimum 50 -Maximum 150
        Add-Coins $player $bonus
        $player.Energy = $player.MaxEnergy
        Write-Host "🎁 DAILY BONUS CLAIMED! +$bonus coins and full energy restore!" -ForegroundColor Magenta
        $player.LastLogin = (Get-Date).ToString()
        Save-Player $player
    } else {
        Write-Host "⏰ Daily bonus already claimed! Come back tomorrow!" -ForegroundColor Gray
    }
}

# Main game loop
function Start-DevLifeSimulator {
    Clear-Host
    Write-Host @"
    ╔═══════════════════════════════════════════════════════════╗
    ║                🎮 DEV LIFE SIMULATOR 🎮                  ║
    ║           The Ultimate PowerShell RPG Experience!        ║
    ╚═══════════════════════════════════════════════════════════╝
"@ -ForegroundColor Magenta

    $player = Load-Player
    
    Write-Host "🎉 Welcome back, $($player.Name)! Level $($player.Level) Developer" -ForegroundColor Cyan
    
    while ($true) {
        Write-Host "`n" + "="*60 -ForegroundColor Yellow
        Write-Host "💰 Coins: $($player.Coins) | ⚡ Energy: $($player.Energy)/$($player.MaxEnergy) | ⭐ Level: $($player.Level)" -ForegroundColor White
        Write-Host "`nWhat would you like to do?" -ForegroundColor Cyan
        Write-Host "1. 🗡️  Go on Adventure (20 energy)"
        Write-Host "2. 🛒 Visit Shop"
        Write-Host "3. 📊 View Stats"
        Write-Host "4. 🎁 Claim Daily Bonus"
        Write-Host "5. 💤 Rest (restore energy)"
        Write-Host "6. 🚪 Exit Game"
        
        Write-Host "`nChoice: " -NoNewline -ForegroundColor Yellow
        $choice = Read-Host
        
        switch ($choice) {
            "1" { Start-Adventure $player }
            "2" { Show-Shop $player }
            "3" { Show-Stats $player; Read-Host "`nPress Enter to continue..." }
            "4" { Claim-DailyBonus $player }
            "5" { 
                $player.Energy = $player.MaxEnergy
                Write-Host "😴 You take a power nap and feel refreshed!" -ForegroundColor Green
                Save-Player $player
            }
            "6" { 
                Write-Host "👋 Thanks for playing Dev Life Simulator!" -ForegroundColor Cyan
                Save-Player $player
                break 
            }
            default { Write-Host "❓ Invalid choice! Try again." -ForegroundColor Red }
        }
    }
}

# Quick commands
function Get-DevStats { Show-Stats (Load-Player) }
function Start-DevQuest { Start-Adventure (Load-Player) }
function Open-DevShop { Show-Shop (Load-Player) }

# Aliases for easy access
Set-Alias -Name "devlife" -Value "Start-DevLifeSimulator"
Set-Alias -Name "quest" -Value "Start-DevQuest"
Set-Alias -Name "shop" -Value "Open-DevShop"
Set-Alias -Name "stats" -Value "Get-DevStats"

# Auto-start message
Write-Host "🎮 DEV LIFE SIMULATOR loaded!" -ForegroundColor Magenta
Write-Host "💡 Commands: 'devlife' (main game), 'quest' (quick adventure), 'shop' (quick shop), 'stats' (quick stats)" -ForegroundColor Gray
Write-Host "🚀 Type 'devlife' to start your developer journey!" -ForegroundColor Cyan